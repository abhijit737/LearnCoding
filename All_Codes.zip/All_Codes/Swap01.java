public class Swap01 {
    public static void main(String[] args) {
        int a=10,b=20;
        a = a+b;//30
        b=a-b;//10
        a = a-b;//20
        System.out.println("after swap " +a +" and " +b);
    }
    
}
