// import java.util.Scanner;

public class Recursion {  
    static void p(){ 
    System.out.println( "hello world");  
    p();  
    }  

      
    public static void main(String[] args) {  
    p();  
    }  
    }  