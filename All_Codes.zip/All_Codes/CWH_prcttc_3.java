import java.util.Scanner;


 class CWH_prcttc_3 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter your name:");
        String name = sc.next();
        System.out.println("Hello " +name +" Have a nice day");
    
        
    }
    
}
