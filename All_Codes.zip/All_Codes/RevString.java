
public class RevString {
    public static void main(String[] args) {
        
    }
    
}
