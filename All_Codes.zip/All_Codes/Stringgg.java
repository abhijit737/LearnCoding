public class Stringgg {
    public static void main(String[] args) {
        String name = "VIVEK    ";
        System.out.println(name.trim());
    }
    
}
