//this cannot be used in static method
public class static4 {
    int i=10;
    public static void main(String[] args) {
        System.out.println(this.i);
    }
    
}
