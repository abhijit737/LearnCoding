class Recursion1 {
    static int count = 0;

    static void printhello() {
        count++;

        if (count <= 5) {

            System.out.println("Hello world");
            printhello();
        }
    }

    public static void main(String[] args) {
        printhello();

    }
}