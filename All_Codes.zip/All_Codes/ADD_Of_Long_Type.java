//add two complex number
public class ADD_Of_Long_Type {
    public static void main(String[] args) {
        long a = 1232435;
        long b = 123445;
        long c = a+b;
        System.out.println(c);

    }
    
}
