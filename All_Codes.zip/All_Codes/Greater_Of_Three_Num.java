
public class Greater_Of_Three_Num {
    public static void main(String[] args) {
        int a=10;
        int b=20;
        int c=30;
        if(a>b && a>c){
            System.out.println("a is greater among all.");
        }
        else if (b>a && b>c){
            System.out.println("B is greater.");
        }
        else{
            System.out.println("C is greater");
        }
    }
    
}
