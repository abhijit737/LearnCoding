//package 08_Practice;

public class factorial {
    public static void main(String[] args) {
        int n=80;
        int fact = 1;
        for(int i=1;i<=80;i++){
            fact = fact*i;
        }
        System.out.println(fact);

    }
    
}
