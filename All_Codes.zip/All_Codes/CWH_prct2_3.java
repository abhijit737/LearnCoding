import java.util.Scanner;

public class CWH_prct2_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the value of a");

        
        int a = sc.nextInt();
        sc.close();
    
        System.out.println(a>30);
        
    }
    
    
}
