class Cylinder{
    private int height;
    private int radius;

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getRadius() {
        return this.radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }
}
public class Getter_Setter {
    public static void main(String[] args) {
        
    }
    
}
