import java.util.Scanner;

public class CWH_prcttc_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number:");
        int a = sc.nextInt();
        System.out.println("Enter Second number:");
        int b = sc.nextInt();
        System.out.println("Enter thrid number:");
        int c = sc.nextInt();
        int sum = a+b+c;
        System.out.println("Sum is: "+sum);
    }
    
}
