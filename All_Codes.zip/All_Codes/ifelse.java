
public class ifelse {
    public static void main(String[] args) {
        int a = 10;
        if(a==11)
        System.out.println("I Am 11.");
        else
        System.out.println("I am not 11.");
    
}
    
}
