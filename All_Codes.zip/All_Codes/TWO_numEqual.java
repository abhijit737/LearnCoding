public class TWO_numEqual {
    public static void main(String[] args) {
        int a=10,b=20;
        if(a==b){
            System.out.println("A and B are qual");
        }
        else{
            System.out.println("A is Not Equal To B");
        }
    }

    
}
