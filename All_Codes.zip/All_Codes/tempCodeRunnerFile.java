 // B obj2 = new B();
        // System.out.println("--------------------");

        //  obj2.showB();
        // obj2.showA();