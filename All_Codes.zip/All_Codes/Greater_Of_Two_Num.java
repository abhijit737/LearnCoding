//package 08_Practice;

public class Greater_Of_Two_Num {
    public static void main(String[] args) {
        int a=10;
        int b=12;
        if(a>b){
            System.out.println("a is greater");
        }
        else{
            System.out.println("b is greater.");
        }
    }
    
}
