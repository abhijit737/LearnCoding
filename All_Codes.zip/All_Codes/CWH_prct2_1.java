public class CWH_prct2_1 {
    public static void main(String[] args) {
        float a = 7/4*9/2;
        System.out.println(a);
    }
    
}
