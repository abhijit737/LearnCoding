//if a given number is integer or not
import java.util.Scanner;

public class CWH_prcttc_5 {
    public static void main(String[] args) {
        System.out.println("Enter the number");
        Scanner sc = new Scanner(System.in);
        
        System.out.println(sc.hasNext());
        
    }
    
}