//package 08_Practice;

public class Leap {
    public static void main(String[] args) {
        int year = 2001;
        if(year % 4 == 0){
            System.out.println("The year is leap year");
        }
        else{
            System.out.println("The year is not leap year");
        }
    }
    
}
