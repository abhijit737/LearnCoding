
public class sum_of_n_natural_number {

    static void natural(int n){
       
            System.out.println("The sum of n natural number is :" +(n*(n+1)/2));
        
    }
    public static void main(String args[]){
        natural(6);

    }
    
}
