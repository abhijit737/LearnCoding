//reverse of a array

public class Q5 {
    public static void main(String[] args) {
        int a[] = {1,2,3,4,5};

        for(int i=0;i<=a.length-1;i++){
            System.out.println("The reverse of array is:");
        }
    }
    
}
