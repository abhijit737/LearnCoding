//program to print number from 1 to 10.

class num_oneTo_Ten{
    public static void main(String[] args) {
    
        for(int i=1;i<=10;i++){
            System.out.println(i);
        }
    }
}