public class ArrayMAx {
    public static void main(String[] args) {
        
    }    
}
