public class static2 {
    static int i =10;
     void display(){
       int i=90;
        System.out.println(i);//throws error coz int is not static if int i given static it is ok
    }
    
}
