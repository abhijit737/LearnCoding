public class minimum {
    public static void main(String[] args) {
        int a=10,b=20,c=30;
        if((a<b)&&(a<c)){
            System.out.println(" a is the smallest");
        }
        else if((b<c)&&(b<a)){
            System.out.println("b is smallest");

        }
        else{
            System.out.println("C is smallest");
        }
    }
    
}
