class Stringg{

    public static void main(String[] args) {
        String name = "VIVEK";
        //name = toLowerCase;
        System.out.println("The String in lowerCase is:"+name.toLowerCase());
        
    }
}