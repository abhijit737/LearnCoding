public class CWH_prct2_2 {
    public static void main(String[] args) {
        char grade = 'B';
        grade = (char)(grade+8);
        System.out.println(grade);

        //decrypt
        grade = (char)(grade-8);
        System.out.println(grade);
    }
    
}
